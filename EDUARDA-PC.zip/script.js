// Adiciona animação de rolagem suave para links internos
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Efeito de desvanecimento ao rolar
window.addEventListener('scroll', function() {
    let header = document.querySelector('header');
    header.style.opacity = 1 - window.scrollY / 400;
});

// Função para abrir modal de informações
function openModal(content) {
    const modal = document.createElement('div');
    modal.classList.add('modal');
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close">&times;</span>
            <p>${content}</p>
        </div>
    `;
    document.body.appendChild(modal);

    // Fecha o modal ao clicar no X
    modal.querySelector('.close').addEventListener('click', () => {
        modal.remove();
    });
}

// Exemplo de uso do modal
document.addEventListener('DOMContentLoaded', () => {
    const infoButton = document.createElement('button');
    infoButton.textContent = 'Mais Informações';
    infoButton.onclick = () => openModal('Aqui estão mais detalhes sobre o aquecimento global...');
    document.querySelector('.main-content').appendChild(infoButton);
});